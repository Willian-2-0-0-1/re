package com.example.controller;

import com.example.model.Content;
import com.example.repository.ContentRepository;
import com.example.service.RecaptchaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class ContentController {

    private final ContentRepository contentRepository;
    private final RecaptchaService recaptchaService;

    public ContentController(ContentRepository contentRepository, RecaptchaService recaptchaService) {
        this.contentRepository = contentRepository;
        this.recaptchaService = recaptchaService;
    }

    @GetMapping("/")
    public String index(Model model, @RequestParam(required = false) String search) {
        List<Content> contents;
        if (search != null && !search.isEmpty()) {
            contents = contentRepository.search(search);
        } else {
            contents = contentRepository.findAll();
        }
        model.addAttribute("contents", contents);
        model.addAttribute("newContent", new Content());
        model.addAttribute("search", search);
        return "index";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute Content content, @RequestParam("g-recaptcha-response") String recaptchaToken,
                      RedirectAttributes redirectAttributes) {
        if (!recaptchaService.validateToken(recaptchaToken)) {
            redirectAttributes.addFlashAttribute("errorMessage", "reCAPTCHA validation failed. Please try again.");
            return "redirect:/";
        }

        contentRepository.save(content);
        redirectAttributes.addFlashAttribute("successMessage", "Content saved successfully!");
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        Content content = contentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Content not found"));
        model.addAttribute("content", content);
        return "edit";
    }

    @PostMapping("/update/{id}")
    public String update(@PathVariable Long id, @ModelAttribute Content content,
                        @RequestParam("g-recaptcha-response") String recaptchaToken,
                        RedirectAttributes redirectAttributes) {
        if (!recaptchaService.validateToken(recaptchaToken)) {
            redirectAttributes.addFlashAttribute("errorMessage", "reCAPTCHA validation failed. Please try again.");
            return "redirect:/edit/" + id;
        }

        content.setId(id);
        contentRepository.save(content);
        redirectAttributes.addFlashAttribute("successMessage", "Content updated successfully!");
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id, @RequestParam("g-recaptcha-response") String recaptchaToken,
                        RedirectAttributes redirectAttributes) {
        if (!recaptchaService.validateToken(recaptchaToken)) {
            redirectAttributes.addFlashAttribute("errorMessage", "reCAPTCHA validation failed. Please try again.");
            return "redirect:/";
        }

        contentRepository.deleteById(id);
        redirectAttributes.addFlashAttribute("successMessage", "Content deleted successfully!");
        return "redirect:/";
    }
}
