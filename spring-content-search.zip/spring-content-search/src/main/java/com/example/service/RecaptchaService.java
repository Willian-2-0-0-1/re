package com.example.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class RecaptchaService {

    @Value("${recaptcha.project.id}")
    private String projectId;

    @Value("${recaptcha.api.key}")
    private String apiKey;

    @Value("${recaptcha.site.key}")
    private String siteKey;

    private final RestTemplate restTemplate;

    public RecaptchaService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public boolean validateToken(String token) {
        try {
            String url = "https://recaptchaenterprise.googleapis.com/v1/projects/" + projectId + "/assessments?key=" + apiKey;

            Map<String, Object> event = new HashMap<>();
            event.put("token", token);
            event.put("siteKey", siteKey);

            Map<String, Object> body = new HashMap<>();
            body.put("event", event);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(body, headers);

            ResponseEntity<Map> responseEntity = restTemplate.postForEntity(url, requestEntity, Map.class);
            Map responseBody = responseEntity.getBody();

            if (responseBody != null && responseBody.get("riskAnalysis") != null) {
                Map riskAnalysis = (Map) responseBody.get("riskAnalysis");
                if (riskAnalysis.get("score") != null) {
                    double score = Double.parseDouble(riskAnalysis.get("score").toString());
                    return score >= 0.5;
                }
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
