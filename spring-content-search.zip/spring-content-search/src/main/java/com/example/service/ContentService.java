package com.example.service;

import com.example.model.Content;
import com.example.repository.ContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ContentService {
    
    @Autowired
    private ContentRepository contentRepository;
    
    public List<Content> searchContent(String query) {
        if (query == null || query.trim().isEmpty()) {
            return contentRepository.findAll();
        }
        return contentRepository.search(query.trim());
    }
    
    public Content saveContent(Content content) {
        return contentRepository.save(content);
    }

    public Optional<Content> getContentById(Long id) {
        return contentRepository.findById(id);
    }

    public void deleteContent(Long id) {
        contentRepository.deleteById(id);
    }

    public Content updateContent(Content content) {
        if (content.getId() == null) {
            throw new IllegalArgumentException("Content ID cannot be null for update");
        }
        return contentRepository.save(content);
    }
}
